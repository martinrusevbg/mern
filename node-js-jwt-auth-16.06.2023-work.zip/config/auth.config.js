module.exports = {
    secret: "martinrusevbg-26928cbd72cb358ce04ef3e941c4d9042f0217b583997bab2d6face460a72617"
};
